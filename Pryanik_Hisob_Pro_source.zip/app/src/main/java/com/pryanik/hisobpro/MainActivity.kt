package com.pryanik.hisobpro

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val db by lazy { HisobDb(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32,32,32,32)
        }
        val title = TextView(this).apply {
            text = "🍪 Pryanik Hisob Pro"
            textSize = 28f
            setPadding(0,0,0,24)
        }
        val info = TextView(this).apply {
            text = "Bugungi tushum: 0 so'm\nQarz: 0 so'm\nXarajat: 0 so'm\nFoyda: 0 so'm\n\nHisob turi: dona • karobka • 3 kg"
            textSize = 18f
        }
        val sale = Button(this).apply { text = "Savdo qo'shish" }
        val backup = Button(this).apply { text = "Google Drive Backup / Restore" }
        sale.setOnClickListener { Toast.makeText(this,"Savdo oynasi keyingi modulda ulanadi",Toast.LENGTH_SHORT).show() }
        backup.setOnClickListener { Toast.makeText(this,"Google Drive moduli ulanmoqda",Toast.LENGTH_SHORT).show() }
        root.addView(title); root.addView(info); root.addView(sale); root.addView(backup)
        setContentView(root)
    }
}
