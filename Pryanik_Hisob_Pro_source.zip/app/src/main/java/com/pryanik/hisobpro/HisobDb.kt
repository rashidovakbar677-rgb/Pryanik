package com.pryanik.hisobpro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Sale(
    val id: Long,
    val date: String,
    val customer: String,
    val dona: Double,
    val karobka: Double,
    val kg3: Double,
    val total: Long,
    val paid: Long
) { val debt: Long get() = total - paid }

class HisobDb(private val context: Context) {
    private val prefs = context.getSharedPreferences("pryanik_db", Context.MODE_PRIVATE)
    private val key = "sales"

    fun addSale(s: Sale) {
        val a = JSONArray(prefs.getString(key, "[]"))
        a.put(JSONObject().apply {
            put("id",s.id); put("date",s.date); put("customer",s.customer)
            put("dona",s.dona); put("karobka",s.karobka); put("kg3",s.kg3)
            put("total",s.total); put("paid",s.paid)
        })
        prefs.edit().putString(key,a.toString()).apply()
    }

    fun exportJson(): String = prefs.getString(key, "[]") ?: "[]"

    fun importJson(json: String) {
        JSONArray(json) // validate first
        prefs.edit().putString(key,json).apply()
    }
}
